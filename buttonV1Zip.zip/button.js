// Search Input
const searchInput = document.querySelector('#search-bar input[type="text"]');

searchInput.addEventListener('keypress', function(event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        window.location.href = 'under-construction.html';
    }
});

// loginLogout
const loginButton = document.querySelector('#login-button button');

loginButton.addEventListener('click', function() {
    if (loginButton.textContent === 'Login') {
        loginButton.textContent = 'Logout';
    } else {
        loginButton.textContent = 'Login';
    }
});

// likeButton

document.addEventListener('DOMContentLoaded', function() {
    const likeBoxes = document.querySelectorAll('.like-box');

    likeBoxes.forEach(function(likeBox) {
        const likeCountElement = likeBox.nextElementSibling;
        let likeCount = 0;

        likeBox.addEventListener('click', function() {
            likeCount++;
            likeCountElement.textContent = `${likeCount} likes`;
        });
    });

    const zenLink = document.querySelector('.zen');
    const programmerLink = document.querySelector('#definition2 .text-right a');

    zenLink.addEventListener('click', function(event) {
        event.preventDefault();
        window.location.href = 'buttonUnderConstruction.html';
    });

    programmerLink.addEventListener('click', function(event) {
        event.preventDefault();
        window.location.href = 'buttonUnderConstruction.html';
    });
});