// Search Input
const searchInput = document.querySelector('#search-bar input[type="text"]');

searchInput.addEventListener('keypress', function(event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        window.location.href = 'under-construction.html';
    }
});

// loginLogout
const loginButton = document.querySelector('#login-button button');

loginButton.addEventListener('click', function() {
    if (loginButton.textContent === 'Login') {
        loginButton.textContent = 'Logout';
    } else {
        loginButton.textContent = 'Login';
    }
});

// likeButton

document.addEventListener('DOMContentLoaded', function() {
    const likeBoxes = document.querySelectorAll('.like-box');

    likeBoxes.forEach(function(likeBox) {
        likeBox.addEventListener('click', function() {
            const word = likeBox.closest('.text-left').querySelector('.main-word').textContent;
            const message = `ninja was liked.`;
            alert(message);
        });
    });
});

// deleteDefinition

document.addEventListener('DOMContentLoaded', function() {
    const addButton = document.querySelector('.green-button');
    let isButtonVisible = true;

    addButton.addEventListener('click', function() {
        if (isButtonVisible) {
            addButton.style.opacity = '0';
        } else {
            addButton.style.opacity = '1';
        }

        isButtonVisible = !isButtonVisible;
    });
});