let profiles = document.getElementsByClassName('profile');

function increaseLikeCount(element) {
    let likeCounter = element.nextElementSibling;
    let likeCount = parseInt(likeCounter.textContent);
    likeCount++;
    likeCounter.textContent = likeCount + ' like(s)';
};