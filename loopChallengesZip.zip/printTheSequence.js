function minusOneAndAHalf(integer) {
    for (var i = 0; i <= 5; i++) {
        console.log(integer - ((i) * 1.5))
    }
}

minusOneAndAHalf(4);