function getFactorial(int) {
    factorial = 1
    for (var i = 1; i <= int; i++) {
        factorial = (factorial * i)
    }
    console.log(factorial)
}

getFactorial(12);