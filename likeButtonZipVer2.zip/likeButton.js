let profiles = document.getElementsByClassName('profile');

function increaseLikeCount(element) {
    let likeCounter = element.parentElement.querySelector('.like-counter');
    let likeCount = parseInt(likeCounter.textContent);
    likeCount++;
    likeCounter.textContent = likeCount + ' like(s)';
}